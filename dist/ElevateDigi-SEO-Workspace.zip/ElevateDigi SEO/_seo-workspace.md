# SEO workspace
agency: ElevateDigi (Kolkata)
timezone: Asia/Kolkata
clients: sif-india, sif-uae, abhyaass, mira-car-rentals, elevatedigi
chrome: dedicated Chrome profile "SEO Lead" (fill in after /seo-setup)
weekly_check: Monday 08:45 IST
approvals_by: (founder names)
baseline: 2026-11-24 crawl of all 5 sites (clients/<slug>/crawls/2026-11-24)
